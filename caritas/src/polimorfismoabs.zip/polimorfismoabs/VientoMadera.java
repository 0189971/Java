package polimorfismoabs;

public class VientoMadera extends Viento {
	public String toString() { 
		return "VientoMadera"; 
	}
}
