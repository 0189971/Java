package polimorfismoabs;

public enum NotaMusical {
    Do, Re, Mi, Fa, Sol, La, Si;
}
