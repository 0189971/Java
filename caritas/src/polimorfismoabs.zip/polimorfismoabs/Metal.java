package polimorfismoabs; 

public class Metal extends Viento {
	public String toString() { 
		return "Metal"; 
	}
}
