package patron;
public class FlujosFactory implements IFlujosFactory {
    @Override
	public FlujoDeEntrada creaFlujoDeEntrada1() {
		return new FlujoBufferedReader();
	}
    @Override
    public FlujosDeEntrada creaFlujoDeEntrada() {
        return new FlujoBufferedInputStream();
    }
    public FlujosDeEntradaTexto creaFlujoDeEntradaTexto() {
        return new FlujoFileReader();
    }
    @Override
    public FlujoAleatorio creaFlujoAleatorio() {
        return new FlujoRandomAccessFile();
    }
    @Override
    public FlujoDeSalida creaFlujoDeSalida1() {
        return new FlujoBufferedWriter();
    }
    @Override
	public FlujosDeSalida creaFlujoDeSalida() {
        return new FlujoBufferedOutputStream();
    }
    public FlujosDeSalidaTexto creaFlujoDeSalidaTexto() {
        return new FlujoFileWriter();
    }
    
}