package vista;

import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.*;
/*
 * Created by JFormDesigner on Thu Apr 03 20:54:39 CST 2014
 */



/**
 * @author SHOCKIE
 */
public class JFrameLogin extends JFrame {
    private JPanelLogin panel;
	public JFrameLogin() {
        super();
		initComponents();
        this.setSize( 390, 230 );
        this.setVisible( true );
        this.addWindowListener(new TomadorDeEventoFrame());
        this.setResizable( false );
	}
    private class TomadorDeEventoFrame implements WindowListener {

        @Override
        public void windowOpened(WindowEvent we) {
            
        }

        @Override
        public void windowClosing(WindowEvent we) {
            System.exit( 0 );
        }

        @Override
        public void windowClosed(WindowEvent we) {
            System.exit( 0 );
        }

        @Override
        public void windowIconified(WindowEvent we) {
            
        }

        @Override
        public void windowDeiconified(WindowEvent we) {
            
        }

        @Override
        public void windowActivated(WindowEvent we) {
            
        }

        @Override
        public void windowDeactivated(WindowEvent we) {
            
        }
    
    }

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner Open Source Project license - unknown

		//======== this ========
		setTitle("Login");
		Container contentPane = getContentPane();
		contentPane.setLayout(null);
        
        //---- panel ----
        panel = new JPanelLogin();
        contentPane.add( panel );
        panel.setBounds( 1, 1, 388, 228);

		{ // compute preferred size
			Dimension preferredSize = new Dimension();
			for(int i = 0; i < contentPane.getComponentCount(); i++) {
				Rectangle bounds = contentPane.getComponent(i).getBounds();
				preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
				preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
			}
			Insets insets = contentPane.getInsets();
			preferredSize.width += insets.right;
			preferredSize.height += insets.bottom;
			contentPane.setMinimumSize(preferredSize);
			contentPane.setPreferredSize(preferredSize);
		}
		pack();
		setLocationRelativeTo(getOwner());
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner Open Source Project license - unknown
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
