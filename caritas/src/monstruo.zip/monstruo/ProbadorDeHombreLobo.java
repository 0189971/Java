/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package monstruo;

/**
 *
 * @author sdelaot
 */
public class ProbadorDeHombreLobo {
    public static void main( String [] args ) {
        HombreLobo luis = new HombreLobo();
        luis.actuar();
    }
}
