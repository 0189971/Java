package monstruo;

public interface IMonstruo{

   public void amenazar();

}
