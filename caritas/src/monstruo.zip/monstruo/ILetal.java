package monstruo;

public interface ILetal extends IMonstruo {

   public void matar() throws Exception, MuertoException;

}
