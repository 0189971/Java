/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package monstruo;

/**
 *
 * @author sdelaot
 */
public class HombreLobo implements ILobo {

    @Override
    public void destrozar() {
        System.out.println( "Destrozando..." );
    }

    @Override
    public void esconderse() {
        System.out.println( "Escondiendose..." );
    }

    @Override
    public void matar() throws Exception, MuertoException {
        int n = (int)(Math.random()*10.0);
        System.out.println( "Matando..." );
        if( n>=5 ) {
            throw new MuertoException( "Estas muerto" );
            }
    }

    @Override
    public void amenazar() {
        System.out.println( "Amenazando..." );
    }
    public void actuar() {
        esconderse();
        amenazar();
        try {
            matar();
        } catch( MuertoException me ) {
            me.printStackTrace();
        } catch( Exception e ) {
            e.printStackTrace();
        }
        destrozar();
    }
}
