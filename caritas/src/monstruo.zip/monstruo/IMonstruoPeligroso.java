package monstruo;

public interface IMonstruoPeligroso extends IMonstruo{

   public void destruir();

}
