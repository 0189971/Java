package monstruo;

public interface IVampiro extends ILetal,IMonstruoPeligroso{

   public void bebeSangre();

}
