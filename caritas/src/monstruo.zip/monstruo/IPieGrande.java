/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package monstruo;

/**
 *
 * @author sdelaot
 */
public interface IPieGrande {
    public void esconderse();
}
