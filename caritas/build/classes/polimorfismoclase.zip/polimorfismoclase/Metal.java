package polimorfismoclase; 

public class Metal extends Viento {
//	public String toString() { 
//		return "Metal"; 
//	}
}
