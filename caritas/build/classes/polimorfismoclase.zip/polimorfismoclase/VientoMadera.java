package polimorfismoclase;

public class VientoMadera extends Viento {
//	public String toString() { 
//		return "VientoMadera"; 
//	}
}
