/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author sdelaot
 */
public class Profesor extends Empleado {
    public String comer() {
        return "Elegantemente";
    }
}
