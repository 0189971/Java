/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author sdelaot
 */
public class Empleado extends Persona {
    public String comer() {
        return "Moderadamente";
    }
}
