/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author sdelaot
 */
public class Persona implements SerHumano {
    public String comer() {
        return "Apresuradamente";
    }
    public String caminar() {
        return "A buen paso";
    }
}
