/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package polimorfismo;

/**
 *
 * @author sdelaot
 */
public interface SerHumano {
    public String comer(); 
    public String caminar(); 
}
