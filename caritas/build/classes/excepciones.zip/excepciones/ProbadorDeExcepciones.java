/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

import javax.swing.*;

/**
 
*/
public class ProbadorDeExcepciones {
	public static void main( String [] args ) {
		FrameDePruebaDeExcepciones frame = 
                new FrameDePruebaDeExcepciones();
		frame.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		frame.setVisible(true);
	}
}
