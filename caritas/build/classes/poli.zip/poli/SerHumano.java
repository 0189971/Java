/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package poli;

/**
 *
 * @author sdelaot
 */
public interface SerHumano {
    public String caminar();
    public void pensar( String pensamiento );
}
