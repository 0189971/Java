package polimorfismointer;

public interface Instrumento {
	void tocar( NotaMusical oNm );
	void ajustar();
}
