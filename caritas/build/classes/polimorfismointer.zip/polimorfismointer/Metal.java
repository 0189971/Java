package polimorfismointer; 

public class Metal extends Viento {
    @Override
	public String toString() { 
		return "Metal"; 
	}
}
