package polimorfismointer;

public class VientoMadera extends Viento {
    @Override
	public String toString() { 
		return "VientoMadera"; 
	}
}
