/*
 * Paquete al que pertenece la clase.
 */
package polimorGUI;

/**
 *
 * @author sdelaot
 */
public class ProbadorDeGUI {
    public static void main( String [] args ) {
        FramePrincipal fp = new FramePrincipal();
        fp.setSize( 400, 200 );
        fp.setVisible( true );
        
    }
//    static {
//        FramePrincipal fp = new FramePrincipal();
//        fp.setSize( 400, 200 );
//        fp.setVisible( true );
//        System.exit(0);
//    }
}
