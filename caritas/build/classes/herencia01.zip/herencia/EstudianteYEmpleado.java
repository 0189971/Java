/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author sdelaot
 */
public class EstudianteYEmpleado extends Estudiante implements IEmpleado {
    private String nss;
    public EstudianteYEmpleado() {
        this( "", 0, "", "", 0.0, "", "" );
    }
    public EstudianteYEmpleado( String nombre, int edad, String curp, 
        String carrera, double promedio, String boleta, 
            String nss ) {
        super( nombre, edad, curp, 
            carrera, promedio, boleta );
        this.nss = nss;
    }
    public EstudianteYEmpleado( EstudianteYEmpleado eye ) {
        super( eye );
        this.nss = eye.nss;
    }
    @Override
    public void cobrar( double salario ) {
        System.out.println( " Gano " + salario  );
    }
    @Override
    public void trabajar( String deQue ) {
        System.out.println( " Trabajo de " + deQue );
    }
    @Override
    public String toString() {
        return super.toString() +
                " nss  : " + nss;
    }
}
