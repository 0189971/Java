/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author sdelaot
 */
public class ProbadorDeJerarquia {
    public static void main( String [] args ) {
        Estudiante alguien = new Estudiante( "Saul", 22, "XXXXXXXXXXXXXX",
            "ICE", 7.0, "201056789" );
        System.out.println( alguien );
    }
}
