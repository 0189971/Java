/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author sdelaot
 */
public class ProbadorDeHerenciaMultiple {
    public static void main( String [] args ) {
        EstudianteYEmpleado alguien = new EstudianteYEmpleado( "Saul", 22, "XXXXXXXXXXXXXX",
            "ICE", 7.0, "201056789", "XXXXXXXXXX" );
        System.out.println( alguien );
        alguien.trabajar( "Profesor" );
        alguien.cobrar( 10.0 );
    }
}
