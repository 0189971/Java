/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author sdelaot
 */
public class Estudiante extends Persona {
    private String carrera;
    private double promedio;
    private String boleta;
    public Estudiante() {
        this( "", 0, "", "", 0.0, "" );
    }
    public Estudiante( String nombre, int edad, String curp, 
        String carrera, double promedio, String boleta ) {
        super( nombre, edad, curp );
        this.carrera = carrera;
        this.promedio = promedio;
        this.boleta = boleta;
    }
    public Estudiante( Estudiante unEstudiante ) {
        super( unEstudiante );
        this.carrera = unEstudiante.carrera;
        this.promedio = unEstudiante.promedio;
        this.boleta = unEstudiante.boleta;
    }
    @Override
    public String toString() {
        return super.toString() +
                " Carrera  : " + carrera + "\n" +
                " Promedio : " + promedio + "\n" +
                " Boleta   : " + boleta + "\n";
    }
}
