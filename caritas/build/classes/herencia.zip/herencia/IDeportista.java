/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author sdelaot
 */
public interface IDeportista {
    public int entrenar( int caloriasAQuemar, String como );
    public void calentar( int minutos );
}
